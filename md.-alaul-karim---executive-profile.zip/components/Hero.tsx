
import React from 'react';

interface HeroProps {
  onNavigate: (tab: string) => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <div className="hero-gradient relative overflow-hidden py-24 md:py-32">
      {/* Decorative Grid */}
      <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 0h40v40H0V0zm1 1h38v38H1V1z' fill='%23ffffff' fill-opacity='0.4' fill-rule='evenodd'/%3E%3C/svg%3E")` }}></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full border border-white/20 glass">
              <span className="flex h-2 w-2 rounded-full bg-corporate-600 animate-pulse"></span>
              <span className="text-[10px] text-blue-200 font-bold tracking-widest uppercase">Cross-Border Advisor</span>
            </div>
            
            <h1 className="font-serif text-5xl md:text-7xl font-bold text-white leading-[1.1]">
              The <span className="text-corporate-600">Human API</span> <br/> 
              for Trade Finance.
            </h1>
            
            <p className="text-slate-400 text-lg md:text-xl leading-relaxed">
              Bridging global capital markets with Bangladeshi operational realities. 
              Scaling growth through <span className="text-white font-semibold">Strategic Compliance</span>, 
              <span className="text-white font-semibold"> Fintech Integration</span>, and 
              <span className="text-white font-semibold"> Institutional Advisory</span>.
            </p>

            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onNavigate('expertise')}
                className="bg-corporate-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl font-bold transition-all shadow-2xl shadow-blue-500/40 flex items-center gap-2 group"
              >
                Explore Expertise
                <i className="fas fa-arrow-right group-hover:translate-x-1 transition-transform"></i>
              </button>
              <button 
                onClick={() => onNavigate('profile')}
                className="bg-white/5 hover:bg-white/10 text-white border border-white/20 px-8 py-4 rounded-xl font-bold transition-all glass"
              >
                Executive Bio
              </button>
            </div>
          </div>

          {/* Stats Display */}
          <div className="grid grid-cols-2 gap-6">
            {[
              { label: 'Transaction Value', val: '$1B+', icon: 'fa-chart-line' },
              { label: 'Global Banking Partners', val: '45+', icon: 'fa-landmark' },
              { label: 'Successful LCs', val: '165+', icon: 'fa-file-invoice-dollar' },
              { label: 'Industry Expertise', val: '15 Yrs', icon: 'fa-award' }
            ].map((stat, i) => (
              <div key={i} className="glass p-8 rounded-2xl border border-white/10 flex flex-col items-start gap-4 hover:border-corporate-600 transition-all group">
                <div className="w-12 h-12 rounded-lg bg-corporate-600/20 flex items-center justify-center text-corporate-600 group-hover:bg-corporate-600 group-hover:text-white transition-all">
                  <i className={`fas ${stat.icon} text-xl`}></i>
                </div>
                <div>
                  <div className="text-3xl font-black text-white">{stat.val}</div>
                  <div className="text-xs text-slate-500 font-bold uppercase tracking-widest">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bridge Decorative Element */}
      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-corporate-600/50 to-transparent"></div>
    </div>
  );
};

export default Hero;
