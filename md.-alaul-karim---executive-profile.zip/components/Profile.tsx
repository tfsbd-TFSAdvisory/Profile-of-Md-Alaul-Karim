
import React from 'react';

const Profile: React.FC = () => {
  return (
    <div className="bg-white py-20 animate-slide">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto bg-slate-50 rounded-[40px] overflow-hidden shadow-2xl border border-slate-200">
          <div className="grid lg:grid-cols-12">
            
            {/* Left Sidebar */}
            <div className="lg:col-span-4 bg-corporate-950 text-white p-12 flex flex-col justify-between relative">
              <div className="relative z-10">
                <div className="w-56 h-56 mx-auto lg:mx-0 rounded-[2rem] bg-slate-800 mb-10 overflow-hidden border-4 border-corporate-600 shadow-2xl transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                  <img 
                    src="https://picsum.photos/seed/karim/600/600" 
                    alt="Md. Alaul Karim" 
                    className="w-full h-full object-cover scale-110"
                  />
                </div>
                <h2 className="font-serif text-3xl font-black mb-2 leading-none">Md. Alaul Karim</h2>
                <p className="text-corporate-600 font-bold tracking-widest uppercase text-sm mb-12 italic">The Human API of Trade Finance</p>
                
                <div className="space-y-6 text-slate-300">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <i className="fas fa-map-marker-alt text-corporate-600"></i>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-slate-500 tracking-tighter">Location</p>
                      <p className="font-semibold text-white">Dhaka & Chattogram</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <i className="fas fa-graduation-cap text-corporate-600"></i>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-slate-500 tracking-tighter">Education</p>
                      <p className="font-semibold text-white">MBA, Finance</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <i className="fas fa-language text-corporate-600"></i>
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase text-slate-500 tracking-tighter">Languages</p>
                      <p className="font-semibold text-white">Bangla (Native), English (Fluent)</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-20 pt-10 border-t border-white/10 relative z-10">
                <p className="text-[10px] uppercase tracking-[0.3em] text-slate-500 font-black mb-6">Digital Presence</p>
                <div className="flex gap-4">
                  {[
                    { icon: 'fa-linkedin-in', link: '#' },
                    { icon: 'fa-globe', link: 'http://www.tfsbd.com' },
                    { icon: 'fa-github', link: '#' }
                  ].map((soc, idx) => (
                    <a key={idx} href={soc.link} className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white hover:bg-corporate-600 hover:border-corporate-600 transition-all duration-300">
                      <i className={`fab ${soc.icon} text-lg`}></i>
                    </a>
                  ))}
                </div>
              </div>

              {/* Decorative Mesh */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-corporate-600/10 blur-[100px] pointer-events-none"></div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-8 p-12 lg:p-20 bg-white">
              <section className="mb-16">
                <h3 className="font-serif text-4xl font-black text-corporate-950 mb-8 flex items-center gap-4">
                  <span className="w-10 h-1 bg-corporate-600 rounded-full"></span>
                  Executive Summary
                </h3>
                <p className="text-slate-600 text-lg leading-relaxed mb-6 font-light">
                  Md. Alaul Karim is a visionary leader specializing in <strong className="text-corporate-950">cross-border trade financing, regulatory compliance, and strategic fintech advisory</strong>. 
                  As the Founder and CEO of Trade Finance Solution Bangladesh (TFSBD), he has redefined how local importers and exporters engage with global capital markets.
                </p>
                <p className="text-slate-600 text-lg leading-relaxed mb-10 font-light">
                  Known for his ability to "contextualize" complex global platforms like <strong className="text-corporate-600">SAP (Taulia)</strong> for the Bangladeshi SME market, Karim serves as a strategic bridge, transforming high-level financial theory into actionable local outcomes.
                </p>
              </section>

              <section>
                <h3 className="font-bold text-xl text-corporate-950 mb-8 uppercase tracking-widest">Professional Journey</h3>
                <div className="space-y-12">
                  <div className="relative pl-10 border-l-2 border-slate-100 group">
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-200 border-4 border-white group-hover:bg-corporate-600 group-hover:scale-125 transition-all"></div>
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-black text-xl text-corporate-900">Founder & CEO</h4>
                      <span className="text-xs font-bold px-3 py-1 bg-slate-100 rounded-full text-slate-500">2018 — Present</span>
                    </div>
                    <p className="text-corporate-600 font-bold mb-4">Trade Finance Solution Bangladesh (TFSBD)</p>
                    <ul className="space-y-2 text-slate-500 text-sm">
                      <li className="flex gap-2"><i className="fas fa-check text-corporate-600 mt-1"></i> Facilitated $1B+ in cumulative trade transaction value.</li>
                      <li className="flex gap-2"><i className="fas fa-check text-corporate-600 mt-1"></i> Designed bilingual regulatory compliance libraries for 165+ major clients.</li>
                      <li className="flex gap-2"><i className="fas fa-check text-corporate-600 mt-1"></i> Established 45+ global banking corridors for local importers.</li>
                    </ul>
                  </div>

                  <div className="relative pl-10 border-l-2 border-slate-100 group">
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-slate-200 border-4 border-white group-hover:bg-corporate-600 group-hover:scale-125 transition-all"></div>
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-black text-xl text-corporate-900">Manager, Operations</h4>
                      <span className="text-xs font-bold px-3 py-1 bg-slate-100 rounded-full text-slate-500">2013 — 2015</span>
                    </div>
                    <p className="text-corporate-600 font-bold mb-4">ITTSBD</p>
                    <p className="text-slate-500 text-sm leading-relaxed">
                      Orchestrated end-to-end operational functions for high-volume financial data processing, significantly improving transaction speed and accuracy.
                    </p>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
