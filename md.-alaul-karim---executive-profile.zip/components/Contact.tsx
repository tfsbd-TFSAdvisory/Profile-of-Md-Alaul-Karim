
import React from 'react';

const Contact: React.FC = () => {
  return (
    <section className="py-24 bg-white animate-slide">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-20">
            
            <div className="space-y-12">
              <div>
                <h2 className="font-serif text-5xl font-black text-corporate-950 mb-6">Initiate <br/> a Dialogue.</h2>
                <p className="text-slate-500 text-lg font-light leading-relaxed">
                  Available for strategic advisory, fintech consulting, and global trade partnerships. 
                  Let's strengthen Bangladesh's position in the global trade ecosystem together.
                </p>
              </div>

              <div className="space-y-8">
                <div className="flex gap-6 items-start group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-corporate-600 group-hover:bg-corporate-900 group-hover:text-white transition-all">
                    <i className="fas fa-envelope text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-black text-corporate-950 text-lg">Direct Inquiry</h4>
                    <p className="text-corporate-600 font-bold mb-1">a.karim@tfsbd.com</p>
                    <p className="text-slate-400 text-xs uppercase font-black tracking-widest">Expect response in 24h</p>
                  </div>
                </div>

                <div className="flex gap-6 items-start group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-corporate-600 group-hover:bg-corporate-900 group-hover:text-white transition-all">
                    <i className="fas fa-phone-alt text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-black text-corporate-950 text-lg">Operational Hotline</h4>
                    <p className="text-corporate-600 font-bold mb-1">+880 1721 117 665</p>
                    <p className="text-slate-400 text-xs uppercase font-black tracking-widest">Mon - Fri, 10am - 6pm</p>
                  </div>
                </div>

                <div className="flex gap-6 items-start group">
                  <div className="w-14 h-14 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-center text-corporate-600 group-hover:bg-corporate-900 group-hover:text-white transition-all">
                    <i className="fas fa-building text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-black text-corporate-950 text-lg">Headquarters</h4>
                    <p className="text-slate-600 font-bold mb-1">TFSBD Advisory Center</p>
                    <p className="text-slate-400 text-xs leading-tight">Dhaka, Bangladesh</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-10 md:p-14 rounded-[3rem] border border-slate-200 shadow-xl">
              <h3 className="font-serif text-2xl font-bold mb-10 text-corporate-950">Professional Message</h3>
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Full Name</label>
                    <input type="text" className="w-full bg-white border border-slate-200 rounded-xl px-5 py-3 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all" />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Company</label>
                    <input type="text" className="w-full bg-white border border-slate-200 rounded-xl px-5 py-3 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all" />
                  </div>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Professional Email</label>
                  <input type="email" className="w-full bg-white border border-slate-200 rounded-xl px-5 py-3 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all" />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Inquiry Type</label>
                  <select className="w-full bg-white border border-slate-200 rounded-xl px-5 py-3 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all">
                    <option>Institutional Advisory</option>
                    <option>Fintech Consulting</option>
                    <option>Compliance Audit</option>
                    <option>Other Professional Matter</option>
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Brief Requirements</label>
                  <textarea rows={4} className="w-full bg-white border border-slate-200 rounded-xl px-5 py-3 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all"></textarea>
                </div>
                <button className="w-full bg-corporate-900 text-white font-black py-5 rounded-2xl hover:bg-corporate-600 transition-all shadow-xl hover:shadow-blue-500/20 uppercase tracking-[0.2em] text-xs">
                  Send Advisory Request
                </button>
              </form>
            </div>

          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
