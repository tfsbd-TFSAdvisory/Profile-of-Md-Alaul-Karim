
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';

const Advisor: React.FC = () => {
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([
    { role: 'model', text: "Welcome. I am Md. Alaul Karim's digital twin. How can I help you navigate the complexities of trade finance in Bangladesh today?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMessage,
        config: {
          systemInstruction: `You are a digital advisory agent representing Md. Alaul Karim, Founder and CEO of Trade Finance Solution Bangladesh (TFSBD). 
          Your knowledge base includes:
          - Cross-border trade financing (LCs, Bank Guarantees).
          - Bangladesh Bank regulatory compliance.
          - Fintech integration (SAP/Taulia).
          - Professional history (MBA Finance, Manager at ITTSBD).
          - Your tone is executive, professional, yet helpful. 
          - You act as a "Human API" bridging global finance with local SME operations.
          - If asked about fees or specific personal contact, refer them to the contact page of the website.
          Keep responses concise and expert.`
        }
      });

      setMessages(prev => [...prev, { role: 'model', text: response.text || "I apologize, I'm having trouble processing that query." }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'model', text: "My apologies, my digital advisory link is momentarily offline." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-corporate-600 font-black tracking-widest text-xs uppercase mb-4 block">AI Synergy</span>
            <h2 className="font-serif text-4xl font-black text-corporate-900 mb-6">Trade Finance AI Advisor</h2>
            <p className="text-slate-600 leading-relaxed text-lg mb-8 font-light">
              Experience the "Human API" firsthand. This digital twin is trained on Md. Alaul Karim's 
              professional philosophies and the regulatory landscape of Bangladesh. Ask about 
              structuring LCs, fintech integration, or market entry strategies.
            </p>
            <div className="p-6 bg-white border border-slate-200 rounded-3xl shadow-sm">
              <h4 className="font-bold text-corporate-950 mb-4 flex items-center gap-2">
                <i className="fas fa-lightbulb text-amber-500"></i>
                Sample Inquiries
              </h4>
              <div className="flex flex-wrap gap-2">
                {["Explain LC structuring", "SAP Taulia benefits", "BB Regulations", "TFSBD's mission"].map((q, i) => (
                  <button 
                    key={i} 
                    onClick={() => setInput(q)}
                    className="text-xs bg-slate-50 border border-slate-200 hover:border-corporate-600 px-3 py-1.5 rounded-full transition-all text-slate-600"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-200 overflow-hidden h-[600px] flex flex-col">
            <div className="bg-corporate-900 p-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-corporate-600 flex items-center justify-center text-white">
                  <i className="fas fa-robot"></i>
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Karim Digital Advisor</h3>
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Online • Powered by Gemini</span>
                </div>
              </div>
              <button className="text-slate-400 hover:text-white transition-colors">
                <i className="fas fa-ellipsis-v"></i>
              </button>
            </div>

            <div 
              ref={scrollRef}
              className="flex-grow overflow-y-auto p-6 space-y-4 bg-slate-50/50"
            >
              {messages.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                    msg.role === 'user' 
                      ? 'bg-corporate-600 text-white rounded-tr-none' 
                      : 'bg-white text-slate-700 border border-slate-100 rounded-tl-none'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-white p-4 rounded-2xl border border-slate-100 rounded-tl-none flex gap-1">
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                    <span className="w-1.5 h-1.5 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 bg-white border-t border-slate-100">
              <div className="relative flex items-center">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Ask a question..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl py-4 pl-6 pr-16 focus:ring-2 focus:ring-corporate-600 focus:outline-none transition-all"
                />
                <button 
                  onClick={handleSend}
                  disabled={isLoading}
                  className="absolute right-2 w-12 h-12 bg-corporate-900 text-white rounded-xl flex items-center justify-center hover:bg-corporate-600 transition-all disabled:opacity-50"
                >
                  <i className="fas fa-paper-plane"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Advisor;
