
import React from 'react';

interface FooterProps {
  onNavigate: (tab: string) => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-corporate-950 text-slate-400 py-20 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-2 space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-corporate-600 text-white flex items-center justify-center rounded-lg font-serif font-bold text-xl">
                AK
              </div>
              <h2 className="text-white text-2xl font-serif font-black tracking-tight">Md. Alaul Karim</h2>
            </div>
            <p className="max-w-md leading-relaxed text-slate-500">
              Leading the digital transformation of cross-border trade in Bangladesh. 
              Founder of TFSBD Advisory — empowering global growth through local expertise.
            </p>
          </div>
          
          <div>
            <h3 className="text-white font-black text-xs uppercase tracking-widest mb-6">Exploration</h3>
            <ul className="space-y-3 text-sm">
              <li><button onClick={() => onNavigate('home')} className="hover:text-corporate-600 transition-colors">Digital Ecosystem</button></li>
              <li><button onClick={() => onNavigate('profile')} className="hover:text-corporate-600 transition-colors">Executive Bio</button></li>
              <li><button onClick={() => onNavigate('expertise')} className="hover:text-corporate-600 transition-colors">Service Modules</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-corporate-600 transition-colors">Contact Center</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-black text-xs uppercase tracking-widest mb-6">Verified Links</h3>
            <div className="flex gap-4">
              {[
                { icon: 'fa-linkedin-in', link: '#' },
                { icon: 'fa-twitter', link: '#' },
                { icon: 'fa-github', link: '#' }
              ].map((soc, i) => (
                <a key={i} href={soc.link} className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-white hover:bg-corporate-600 transition-all">
                  <i className={`fab ${soc.icon}`}></i>
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-700">
            &copy; 2026 Trade Finance Solution Bangladesh (TFSBD). All Professional Rights Reserved.
          </p>
          <div className="flex gap-8 text-[10px] font-black uppercase tracking-widest text-slate-700">
            <a href="#" className="hover:text-slate-400">Privacy Policy</a>
            <a href="#" className="hover:text-slate-400">Compliance Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
