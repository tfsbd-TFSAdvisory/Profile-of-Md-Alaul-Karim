
import React, { useState } from 'react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'profile', label: 'Executive Bio' },
    { id: 'expertise', label: 'Core Expertise' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-slate-200">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => setActiveTab('home')}
        >
          <div className="w-10 h-10 bg-corporate-900 text-white flex items-center justify-center rounded-lg font-serif font-bold text-xl group-hover:bg-corporate-600 transition-colors duration-300">
            AK
          </div>
          <div>
            <h1 className="text-lg font-black text-corporate-950 leading-none">Md. Alaul Karim</h1>
            <span className="text-[10px] text-corporate-600 font-bold tracking-widest uppercase">CEO & Founder, TFSBD</span>
          </div>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-10">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`text-sm font-semibold transition-all duration-300 relative py-1 ${
                activeTab === item.id 
                  ? 'text-corporate-600 nav-active' 
                  : 'text-slate-500 hover:text-corporate-900'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button 
            onClick={() => setActiveTab('contact')}
            className="bg-corporate-900 text-white px-5 py-2 rounded-full text-xs font-bold hover:bg-corporate-600 transition-all shadow-lg hover:shadow-blue-500/20"
          >
            Work with Me
          </button>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-slate-800"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars-staggered'} text-2xl`}></i>
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 p-6 absolute w-full shadow-2xl animate-slide">
          <div className="flex flex-col space-y-4">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`text-left text-lg font-bold ${
                  activeTab === item.id ? 'text-corporate-600' : 'text-slate-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
