
import React from 'react';

const Expertise: React.FC = () => {
  const skills = [
    {
      title: "Cross-Border Finance",
      icon: "fa-file-invoice-dollar",
      desc: "Deep expertise in structuring Letters of Credit (LCs), Bank Guarantees, Forfaiting, and Supply Chain Finance solutions.",
      color: "blue"
    },
    {
      title: "Digital Fintech Integration",
      icon: "fa-laptop-code",
      desc: "Contextualizing global platforms like SAP/Taulia to drive digital transformation for local SME workflows.",
      color: "indigo"
    },
    {
      title: "Bilingual Compliance",
      icon: "fa-balance-scale",
      desc: "Building modular compliance libraries in Bangla/English for seamless alignment with Bangladesh Bank regulations.",
      color: "emerald"
    },
    {
      title: "Strategic Advisory",
      icon: "fa-handshake",
      desc: "Transforming complex global trade policies into high-value executive reports and actionable business models.",
      color: "amber"
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mb-16">
          <h2 className="font-serif text-4xl md:text-5xl font-black text-corporate-950 mb-6">Core Competencies</h2>
          <p className="text-slate-500 text-lg leading-relaxed">
            Md. Alaul Karim operates at the intersection of traditional banking and futuristic fintech, 
            providing a holistic ecosystem for international trade in Bangladesh.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {skills.map((skill, idx) => (
            <div 
              key={idx} 
              className="group p-8 bg-slate-50 rounded-3xl border border-slate-100 hover:bg-corporate-900 hover:text-white transition-all duration-500 hover:-translate-y-2 shadow-sm hover:shadow-2xl hover:shadow-blue-900/40"
            >
              <div className={`w-14 h-14 rounded-2xl bg-white shadow-md flex items-center justify-center mb-8 group-hover:bg-corporate-600 transition-colors duration-500`}>
                <i className={`fas ${skill.icon} text-2xl text-corporate-900 group-hover:text-white`}></i>
              </div>
              <h3 className="font-serif text-xl font-black mb-4 group-hover:text-white">{skill.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed group-hover:text-slate-400 transition-colors">
                {skill.desc}
              </p>
            </div>
          ))}
        </div>

        {/* The Human API Visual Bridge */}
        <div className="mt-24 p-12 bg-corporate-950 rounded-[3rem] text-white relative overflow-hidden group">
          <div className="relative z-10 grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="font-serif text-3xl font-bold mb-6">The "Human API" Model</h3>
              <p className="text-slate-400 mb-8 leading-relaxed">
                Rather than being just a consultant, Md. Alaul Karim acts as an interface. He "calls" 
                the global market's capital and standards, processes them through the local legal framework, 
                and outputs a simple, functional result for the Bangladeshi merchant.
              </p>
              <div className="space-y-4">
                {[
                  { label: "Input", val: "Global Capital & Standards" },
                  { label: "Processing", val: "TFSBD Compliance Engine" },
                  { label: "Output", val: "Operational Success for SMEs" }
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4 bg-white/5 border border-white/10 p-4 rounded-xl">
                    <span className="text-xs font-black text-corporate-600 w-20 uppercase tracking-tighter">{item.label}</span>
                    <span className="font-bold text-slate-100">{item.val}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative flex justify-center">
              {/* Abstract Visual Bridge */}
              <div className="w-full max-w-md aspect-square rounded-full border border-white/10 flex items-center justify-center animate-spin-slow">
                 <div className="absolute inset-4 rounded-full border border-corporate-600/30"></div>
                 <div className="absolute inset-12 rounded-full border border-white/5"></div>
                 <i className="fas fa-fingerprint text-[120px] text-corporate-600/20"></i>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-corporate-600 text-white p-8 rounded-3xl shadow-2xl font-black text-2xl animate-bounce">
                  BRIDGE
                </div>
              </div>
            </div>
          </div>
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
        </div>
      </div>
    </section>
  );
};

export default Expertise;
